Did DOMMenu version
Added loadDocument and validateDocument to main method
args 0 should be the xml document directory and args 1 should be the schema directory
Added catch(SAXParseException e) and catch(Exception e) to validateDocument method
Rewrote printNode method adding NodeLists and printf with %-20s£%-13s%-1s\n as formatting for printf statement